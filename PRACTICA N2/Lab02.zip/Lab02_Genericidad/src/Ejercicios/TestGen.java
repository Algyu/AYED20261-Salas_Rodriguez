package Ejercicios;

public class TestGen {

    public static void main(String[] args) {

        String[] v = {"Perez", "Sanchez", "Rodriguez"};
        Integer[] w = {12, 34, 56};

        System.out.println(UtilGenerico.exist(v, "Sanchez"));
        System.out.println(UtilGenerico.exist(w, 34));        

        Cajoneria<Golosina> cajoneria = new Cajoneria<>();

        cajoneria.addCaja(new Caja<>("Rojo", new Golosina("Caramelo", 0.5)));
        cajoneria.addCaja(new Caja<>("Azul", new Golosina("Chicle", 0.2)));
        cajoneria.addCaja(new Caja<>("Verde", new Golosina("Chocolate", 1.0)));
        cajoneria.addCaja(new Caja<>("Amarillo", new Golosina("Caramelo", 0.5)));
        cajoneria.addCaja(new Caja<>("Negro", new Golosina("Galleta", 0.8)));

        System.out.println("\nContenido Cajonería:");
        System.out.println(cajoneria);

        System.out.println("Buscar: " +
            cajoneria.search(new Golosina("Caramelo", 0.5)));

        System.out.println("Eliminado: " +
            cajoneria.delete(new Golosina("Chicle", 0.2)));

        System.out.println("Cantidad de Caramelo: " +
            cajoneria.contar(new Golosina("Caramelo", 0.5)));

        System.out.println("\nDespués de eliminar:");
        System.out.println(cajoneria);

        Cajoneria<Chocolatina> cajonCho = new Cajoneria<>();

        cajonCho.addCaja(new Caja<>("Rojo", new Chocolatina("Milka")));
        cajonCho.addCaja(new Caja<>("Azul", new Chocolatina("Ferrero")));

        System.out.println("\nCajonería Chocolatinas:");
        System.out.println(cajonCho);
    }
}