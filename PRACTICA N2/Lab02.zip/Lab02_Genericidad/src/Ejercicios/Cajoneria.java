package Ejercicios;

import java.util.ArrayList;

public class Cajoneria<T> {

    private ArrayList<Caja<T>> cajas = new ArrayList<>();

    public void addCaja(Caja<T> caja) {
        cajas.add(caja);
    }

    public String search(T elemento) {
        for (int i = 0; i < cajas.size(); i++) {
            if (cajas.get(i).getContenido().equals(elemento)) {
                return "Posición: " + i + " | Color: " + cajas.get(i).getColor();
            }
        }
        return "No encontrado";
    }

    public T delete(T elemento) {
        for (Caja<T> caja : cajas) {
            if (caja.getContenido().equals(elemento)) {
                T temp = caja.getContenido();
                caja.setContenido(null);
                return temp;
            }
        }
        return null;
    }

    public int contar(T elemento) {
        int contador = 0;

        for (Caja<T> caja : cajas) {
            if (caja.getContenido() != null &&
                caja.getContenido().equals(elemento)) {
                contador++;
            }
        }

        return contador;
    }

    @Override
    public String toString() {
        String resultado = "";

        for (int i = 0; i < cajas.size(); i++) {
            resultado += (i + 1) + " | "
                    + cajas.get(i).getColor() + " | "
                    + cajas.get(i).getContenido() + "\n";
        }

        return resultado;
    }
}