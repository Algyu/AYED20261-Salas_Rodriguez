/**
 * 
 */
/**
 * 
 */
module Lab02_Genericidad {
}