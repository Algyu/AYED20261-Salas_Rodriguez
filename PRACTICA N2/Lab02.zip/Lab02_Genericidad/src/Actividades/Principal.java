package Actividades;

public class Principal {

    public static void main(String[] args) {

        Bolsa<Chocolatina> bolsaCho = new Bolsa<>(3);

        Chocolatina c = new Chocolatina("Milka");
        Chocolatina c1 = new Chocolatina("Milka");
        Chocolatina c2 = new Chocolatina("Ferrero");

        bolsaCho.add(c);
        bolsaCho.add(c1);
        bolsaCho.add(c2);

        System.out.println("Contenido de bolsa de chocolatinas:");
        for (Chocolatina chocolatina : bolsaCho) {
            System.out.println(chocolatina.getMarca());
        }

        Bolsa<Golosina> bolsaGol = new Bolsa<>(2);
        bolsaGol.add(new Golosina("Caramelo", 0.5));
        bolsaGol.add(new Golosina("Chicle", 0.2));

        System.out.println("\nContenido de bolsa de golosinas:");
        for (Golosina g : bolsaGol) {
            System.out.println(g.getNombre() + " - " + g.getPeso());
        }
    }
}