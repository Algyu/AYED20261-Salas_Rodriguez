package Ejercicios;

class ListaEnlazada6 {

    public static <T> Node<T> concatenarListas(Node<T> l1, Node<T> l2) {
        if (l1 == null) return l2;

        Node<T> actual = l1;
        while (actual.siguiente != null) {
            actual = actual.siguiente;
        }

        actual.siguiente = l2;
        return l1;
    }

    public static void main(String[] args) {
        Node<Integer> l1 = new Node<>(10);
        l1.siguiente = new Node<>(20);

        Node<Integer> l2 = new Node<>(30);
        l2.siguiente = new Node<>(40);

        Node<Integer> resultado = concatenarListas(l1, l2);

        Node<Integer> actual = resultado;
        while (actual != null) {
            System.out.print(actual.dato + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }
}