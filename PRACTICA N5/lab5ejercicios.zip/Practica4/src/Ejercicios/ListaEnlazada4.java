package Ejercicios;

class ListaEnlazada4 {

    public static <T> int contarNodos(Node<T> head) {
        int contador = 0;
        Node<T> actual = head;

        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }

        return contador;
    }

    public static void main(String[] args) {
        Node<Integer> head = new Node<>(10);
        head.siguiente = new Node<>(20);
        head.siguiente.siguiente = new Node<>(30);

        int total = contarNodos(head);
        System.out.println("Total de nodos: " + total);
    }
}