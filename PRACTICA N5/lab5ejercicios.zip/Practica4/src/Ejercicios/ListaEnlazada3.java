package Ejercicios;

class ListaEnlazada3 {

    public static <T> Node<T> insertarAlFinal(Node<T> head, T valor) {
        Node<T> nuevo = new Node<>(valor);

        if (head == null) return nuevo;

        Node<T> actual = head;
        while (actual.siguiente != null) {
            actual = actual.siguiente;
        }

        actual.siguiente = nuevo;
        return head;
    }

    public static void main(String[] args) {
        Node<Integer> head = null;

        head = insertarAlFinal(head, 10);
        head = insertarAlFinal(head, 20);
        head = insertarAlFinal(head, 30);

        Node<Integer> actual = head;
        while (actual != null) {
            System.out.print(actual.dato + " - ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }
}