package Ejercicios;

class ListaEnlazada5 {

    public static <T> boolean sonIguales(Node<T> a, Node<T> b) {
        while (a != null && b != null) {
            if (!a.dato.equals(b.dato)) {
                return false;
            }
            a = a.siguiente;
            b = b.siguiente;
        }
        return a == null && b == null;
    }

    public static void main(String[] args) {
        Node<Integer> l1 = new Node<>(10);
        l1.siguiente = new Node<>(20);

        Node<Integer> l2 = new Node<>(10);
        l2.siguiente = new Node<>(20);

        System.out.println("Son iguales: " + sonIguales(l1, l2));
    }
}