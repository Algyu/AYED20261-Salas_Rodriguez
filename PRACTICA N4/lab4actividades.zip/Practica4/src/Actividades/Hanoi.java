package Actividades;

public class Hanoi {

    public static void main(String[] args) {
        int discos = 2;
        torresHanoi(discos, 1, 2, 3);
    }

    // Método recursivo
    public static void torresHanoi(int discos, int origen, int auxiliar, int destino) {

        // Caso base
        if (discos == 1) {
            System.out.println("Mover disco de torre " + origen + " a torre " + destino);
        } else {
            // Paso 1
            torresHanoi(discos - 1, origen, destino, auxiliar);

            // Paso 2
            System.out.println("Mover disco de torre " + origen + " a torre " + destino);

            // Paso 3
            torresHanoi(discos - 1, auxiliar, origen, destino);
        }
    }
}