package Actividades;

public class ModaDivideVenceras {

    // Funcion para contar frecuencia
    public static int contar(int[] arr, int inicio, int fin, int valor) {
        int count = 0;
        for (int i = inicio; i <= fin; i++) {
            if (arr[i] == valor) count++;
        }
        return count;
    }

    // Funcion principal divide y vencerás
    public static int moda(int[] arr, int inicio, int fin) {

        // Caso base
        if (inicio == fin) {
            return arr[inicio];
        }

        int medio = (inicio + fin) / 2;

        // Dividir
        int izquierda = moda(arr, inicio, medio);
        int derecha = moda(arr, medio + 1, fin);

        // Contar cuál aparece más
        int freqIzq = contar(arr, inicio, fin, izquierda);
        int freqDer = contar(arr, inicio, fin, derecha);

        // Combinar
        if (freqIzq > freqDer) {
            return izquierda;
        } else {
            return derecha;
        }
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 2, 3, 3, 3, 4};

        int resultado = moda(arr, 0, arr.length - 1);
        System.out.println("La moda es: " + resultado);
    }
}