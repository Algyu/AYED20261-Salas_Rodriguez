package Actividades;

import java.util.*;

public class Permutaciones {

    public static void permutar(int[] arr, List<Integer> actual, boolean[] usado) {

        // Caso base ya que tienes una permutación completa
        if (actual.size() == arr.length) {
            System.out.println(actual);
            return;
        }

        for (int i = 0; i < arr.length; i++) {

            if (!usado[i]) {

                // Marcar como usado
                usado[i] = true;

                // Agregar elemento
                actual.add(arr[i]);

                // Llamada recursiva
                permutar(arr, actual, usado);

                // Backtracking (deshacer)
                actual.remove(actual.size() - 1);
                usado[i] = false;
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3};
        boolean[] usado = new boolean[arr.length];

        permutar(arr, new ArrayList<>(), usado);
    }
}
