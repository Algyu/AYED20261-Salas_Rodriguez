package Actividades;

public class NaiveSolucion {

    static int getValue(int[] values, int length) {
        if (length <= 0)
            return 0;

        int max = -1;

        for (int i = 0; i < length; i++) {
            max = Math.max(max, values[i] + getValue(values, length - i - 1));
        }

        return max;
    }

    public static void main(String[] args) {
        int[] values = {3, 7, 1, 3, 9};
        int rodLength = values.length;

        System.out.println("Valor máximo: " + getValue(values, rodLength));
    }
}