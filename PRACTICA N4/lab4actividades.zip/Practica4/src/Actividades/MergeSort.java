package Actividades;

import java.util.Arrays;

public class MergeSort {

    // Método principal
    public static void mergeSort(int[] arr, int izquierda, int derecha) {
        if (izquierda < derecha) {

            int medio = (izquierda + derecha) / 2;

            // Dividir
            mergeSort(arr, izquierda, medio);
            mergeSort(arr, medio + 1, derecha);

            // Combinar
            merge(arr, izquierda, medio, derecha);
        }
    }

    // Método para mezclar
    public static void merge(int[] arr, int izquierda, int medio, int derecha) {

        int n1 = medio - izquierda + 1;
        int n2 = derecha - medio;

        int[] L = new int[n1];
        int[] R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[izquierda + i];

        for (int j = 0; j < n2; j++)
            R[j] = arr[medio + 1 + j];

        int i = 0, j = 0, k = izquierda;

        // Mezcla
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    public static void main(String[] args) {

        // Arreglo de 5 elementos
        int[] arr1 = {8, 3, 5, 2, 9};
        System.out.println("Antes: " + Arrays.toString(arr1));
        mergeSort(arr1, 0, arr1.length - 1);
        System.out.println("Después: " + Arrays.toString(arr1));

        // Arreglo de 8 elementos
        int[] arr2 = {10, 4, 6, 2, 8, 1, 3, 7};
        System.out.println("\nAntes: " + Arrays.toString(arr2));
        mergeSort(arr2, 0, arr2.length - 1);
        System.out.println("Después: " + Arrays.toString(arr2));

        // Arreglo de 10 elementos
        int[] arr3 = {15, 3, 9, 8, 5, 2, 7, 1, 6, 4};
        System.out.println("\nAntes: " + Arrays.toString(arr3));
        mergeSort(arr3, 0, arr3.length - 1);
        System.out.println("Después: " + Arrays.toString(arr3));
    }
}
