package EJERCICIO2;

public class MapaMinero {

    private Zona[][] mapa;
    private int filas;
    private int columnas;

    public MapaMinero(int f, int c) {
        filas = f;
        columnas = c;
        mapa = new Zona[f][c];
    }

    public void setZona(int i, int j, Zona z) {
        mapa[i][j] = z;
    }

    // suma valor de una region k x k
    private double valorRegion(int fi, int ci, int k) {

        double suma = 0;

        for(int i = fi; i < fi + k; i++)
            for(int j = ci; j < ci + k; j++)
                suma += mapa[i][j].valorEconomico();

        return suma;
    }

    public void buscarMejorRegion(int k) {

        double max = -1;
        int mejorF = 0;
        int mejorC = 0;

        // recorrer todas las submatrices
        for(int i = 0; i <= filas - k; i++) {
            for(int j = 0; j <= columnas - k; j++) {

                double valor = valorRegion(i, j, k);

                if(valor > max) {
                    max = valor;
                    mejorF = i;
                    mejorC = j;
                }
            }
        }

        System.out.println("Valor maximo: " + max);
        System.out.println("Inicio region: (" + mejorF + "," + mejorC + ")");

        mostrarRegion(mejorF, mejorC, k);
    }

    private void mostrarRegion(int fi, int ci, int k) {

        java.util.HashMap<String,Integer> contador =
                new java.util.HashMap<>();

        System.out.println("Zonas de la region:");

        for(int i = fi; i < fi + k; i++) {
            for(int j = ci; j < ci + k; j++) {

                Zona z = mapa[i][j];
                System.out.println(z);

                contador.put(
                    z.getMineral(),
                    contador.getOrDefault(z.getMineral(),0)+1
                );
            }
        }

        // mineral predominante
        String dominante = "";
        int max = 0;

        for(String m : contador.keySet()) {
            if(contador.get(m) > max) {
                max = contador.get(m);
                dominante = m;
            }
        }

        System.out.println("Mineral predominante: " + dominante);
    }
}
