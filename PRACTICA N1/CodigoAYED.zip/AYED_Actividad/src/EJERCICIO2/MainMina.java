package EJERCICIO2;
import java.util.Scanner;

public class MainMina {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Filas: ");
        int f = sc.nextInt();

        System.out.print("Columnas: ");
        int c = sc.nextInt();

        MapaMinero mapa = new MapaMinero(f, c);

        for(int i=0;i<f;i++){
            for(int j=0;j<c;j++){

                System.out.println("Zona ["+i+"]["+j+"]");

                String mineral = sc.next();
                double cantidad = sc.nextDouble();
                double pureza = sc.nextDouble();

                mapa.setZona(i,j,
                    new Zona(mineral,cantidad,pureza));
            }
        }

        System.out.print("Ingrese k: ");
        int k = sc.nextInt();

        mapa.buscarMejorRegion(k);
    }
}