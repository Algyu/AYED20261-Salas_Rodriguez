package Actividad1;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Rectangulo A");
        Coordenada a1 = new Coordenada(sc.nextDouble(), sc.nextDouble());
        Coordenada a2 = new Coordenada(sc.nextDouble(), sc.nextDouble());

        System.out.println("Rectangulo B");
        Coordenada b1 = new Coordenada(sc.nextDouble(), sc.nextDouble());
        Coordenada b2 = new Coordenada(sc.nextDouble(), sc.nextDouble());

        Rectangulo A = new Rectangulo(a1, a2);
        Rectangulo B = new Rectangulo(b1, b2);

        System.out.println("Rectangulo A = " + A);
        System.out.println("Rectangulo B = " + B);

        if (Verificador.esSobrePos(A, B)) {
            System.out.println("Se sobreponen");
        } else if (Verificador.esJunto(A, B)) {
            System.out.println("Estan juntos");
        } else {
            System.out.println("Son disjuntos");
        }
    }
}
