    // ACT 2

package Actividad1;

import java.util.Scanner;

public class Main2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ContainerRect cont = new ContainerRect(10);

        for(int i = 0; i < 2; i++) {

            System.out.println("Ingrese esquina 1:");
            Coordenada c1 =
                new Coordenada(sc.nextDouble(), sc.nextDouble());

            System.out.println("Ingrese esquina 2:");
            Coordenada c2 =
                new Coordenada(sc.nextDouble(), sc.nextDouble());

            Rectangulo r = new Rectangulo(c1, c2);

            cont.addRectangulo(r);
        }

        System.out.println("\nContenido del contenedor:");
        System.out.println(cont);
    }
}
