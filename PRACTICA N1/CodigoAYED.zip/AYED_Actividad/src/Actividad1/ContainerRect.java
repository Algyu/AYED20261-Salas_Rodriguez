//ACT 2

package Actividad1;

public class ContainerRect {

    private Rectangulo[] rects;
    private double[] distancias;
    private double[] areas;
    private int n;

    public static int numRec = 0;

    // constructor
    public ContainerRect(int n) {
        this.n = n;
        rects = new Rectangulo[n];
        distancias = new double[n];
        areas = new double[n];
    }

    // agregar rectangulo
    public void addRectangulo(Rectangulo r) {

        if (numRec >= n) {
            System.out.println("No se pueden guardar mas rectangulos");
            return;
        }

        rects[numRec] = r;

        Coordenada c1 = r.getEsquina1();
        Coordenada c2 = r.getEsquina2();

        // distancia diagonal
        distancias[numRec] =
                Coordenada.distancia(c1, c2);

        // area
        areas[numRec] = r.calculoArea();

        numRec++;
    }

    public String toString() {

        String texto = "Rectangulo   Coordenadas   Distancia   Area\n";

        for (int i = 0; i < numRec; i++) {
            texto += (i + 1) + "   "
                    + rects[i] + "   "
                    + String.format("%.3f", distancias[i]) + "   "
                    + String.format("%.2f", areas[i]) + "\n";
        }

        return texto;
    }
}