package Actividad1;

public class Verificador {

    public static boolean esSobrePos(Rectangulo r1, Rectangulo r2) {

        double left1 = Math.min(r1.getEsquina1().getX(), r1.getEsquina2().getX());
        double right1 = Math.max(r1.getEsquina1().getX(), r1.getEsquina2().getX());
        double top1 = Math.max(r1.getEsquina1().getY(), r1.getEsquina2().getY());
        double bottom1 = Math.min(r1.getEsquina1().getY(), r1.getEsquina2().getY());

        double left2 = Math.min(r2.getEsquina1().getX(), r2.getEsquina2().getX());
        double right2 = Math.max(r2.getEsquina1().getX(), r2.getEsquina2().getX());
        double top2 = Math.max(r2.getEsquina1().getY(), r2.getEsquina2().getY());
        double bottom2 = Math.min(r2.getEsquina1().getY(), r2.getEsquina2().getY());

        return !(left1 >= right2 || left2 >= right1 ||
                 top1 <= bottom2 || top2 <= bottom1);
    }

    public static boolean esJunto(Rectangulo r1, Rectangulo r2) {
        return !esSobrePos(r1, r2) &&
               (r1.getEsquina1().getX() == r2.getEsquina2().getX()
               || r1.getEsquina2().getX() == r2.getEsquina1().getX());
    }

    public static boolean esDisjunto(Rectangulo r1, Rectangulo r2) {
        return !esSobrePos(r1, r2) && !esJunto(r1, r2);
    }
}
