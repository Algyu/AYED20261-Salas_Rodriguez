package Actividad1;

public class Coordenada {

    private double x;
    private double y;

    public Coordenada() {
        x = 0;
        y = 0;
    }

    public Coordenada(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Coordenada(Coordenada c) {
        this.x = c.x;
        this.y = c.y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double distancia(Coordenada c) {
        double dx = x - c.x;
        double dy = y - c.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    public static double distancia(Coordenada a, Coordenada b) {
        double dx = a.x - b.x;
        double dy = a.y - b.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    public String toString() {
        return "[" + x + ", " + y + "]";
    }
}
